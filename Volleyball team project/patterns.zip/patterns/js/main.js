$(document).ready(function(){
    $("a.1").click(function(){
        $("div.players").removeClass("hide");
        $("div.staff").addClass("hide");
    });
    $("a.2").click(function(){
        $("div.players").addClass("hide");
        $("div.staff").removeClass("hide");
    });
 });

